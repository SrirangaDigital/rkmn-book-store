SET NAMES 'utf8';

INSERT IGNORE INTO `PREFIX_configuration` (`name`, `value`, `date_add`, `date_upd`) VALUES
('PS_LIMIT_UPLOAD_IMAGE_VALUE', '2', NOW(), NOW()),
('PS_LIMIT_UPLOAD_FILE_VALUE', '2', NOW(), NOW());